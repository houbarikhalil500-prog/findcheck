import { NextResponse } from 'next/server';
import crypto from 'node:crypto';
import { createClient } from '@supabase/supabase-js';
import { demoResults, Result } from '@/lib/demo';
import { tavilySearch, enrichWithGroq } from '@/lib/search';

export const runtime = 'nodejs';

function intentType(query: string) {
  const q = query.toLowerCase();
  if (/\b(وظيفة|عمل|job|career|remote)\b/.test(q)) return 'job';
  if (/\b(لابتوب|هاتف|هاتف|سعر|شراء|منتج|laptop|phone|buy|price)\b/.test(q)) return 'product';
  if (/\b(دورة|تعلم|كورس|course|learn|certificate)\b/.test(q)) return 'course';
  if (/\b(موقع|رابط|موثوق|احتيال|scam|website|trust)\b/.test(q)) return 'check';
  return 'general';
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const query = String(body?.query ?? '').trim().slice(0, 500);
    const country = String(body?.country ?? 'DZ').toUpperCase().slice(0, 2);
    if (!query) return NextResponse.json({ error: 'query_required' }, { status: 400 });

    let results: Result[];
    let demo = false;
    if (process.env.TAVILY_API_KEY) {
      try {
        results = await tavilySearch(query, country);
        results = await enrichWithGroq(query, results);
      } catch {
        results = demoResults(query);
        demo = true;
      }
    } else {
      results = demoResults(query);
      demo = true;
    }
    const hash = crypto.createHash('sha256').update(`${country}:${query.toLowerCase()}`).digest('hex');

    const supabaseUrl = process.env.SUPABASE_URL;
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (supabaseUrl && serviceKey) {
      const supabase = createClient(supabaseUrl, serviceKey, { auth: { persistSession: false } });
      const { data: search } = await supabase
        .schema('findcheck')
        .from('searches')
        .insert({ query_hash: hash, intent_type: intentType(query), country_code: country })
        .select('id')
        .single();

      if (!demo) {
        const current = await supabase.schema('findcheck').from('providers').select('usage_count').eq('name','Tavily').single();
        await supabase.schema('findcheck').from('providers').update({ usage_count: Number(current.data?.usage_count ?? 0) + 1 }).eq('name','Tavily');
      }

      if (search?.id) {
        await supabase.schema('findcheck').from('results').insert(
          results.map((r, i) => ({
            search_id: search.id,
            title: r.title,
            url: r.url,
            source_name: r.source,
            description: r.description,
            price_text: r.price ?? null,
            result_type: r.type,
            sponsored: r.sponsored,
            evidence: { evidence: r.evidence, risk: r.risk },
            position: i + 1,
          }))
        );
      }
    }

    return NextResponse.json({ results, demo, intent: intentType(query), country });
  } catch {
    return NextResponse.json({ error: 'search_failed' }, { status: 500 });
  }
}
