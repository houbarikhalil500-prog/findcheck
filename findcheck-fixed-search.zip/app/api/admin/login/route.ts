import { NextResponse } from 'next/server';
import { adminCookieName, adminCookieValue } from '@/lib/server/admin';

export const runtime = 'nodejs';

export async function POST(req: Request) {
  const { password } = await req.json().catch(() => ({}));
  const configured = process.env.ADMIN_PASSWORD;
  if (!configured || String(password ?? '') !== configured) {
    return NextResponse.json({ error: 'invalid_credentials' }, { status: 401 });
  }
  const response = NextResponse.json({ ok: true });
  response.cookies.set(adminCookieName, adminCookieValue(), {
    httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/', maxAge: 60 * 60 * 24 * 7,
  });
  return response;
}
