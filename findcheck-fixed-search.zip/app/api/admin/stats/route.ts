import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { isAdmin } from '@/lib/server/admin';
export const runtime = 'nodejs';

export async function GET() {
  if (!(await isAdmin())) return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return NextResponse.json({ configured: false, stats: null });
  const db = createClient(url, key, { auth: { persistSession: false } });
  const schema = db.schema('findcheck');
  const [searches, clicks, revenue, providers, sources] = await Promise.all([
    schema.from('searches').select('id', { count: 'exact', head: true }),
    schema.from('clicks').select('id', { count: 'exact', head: true }),
    schema.from('revenue_events').select('amount,status,currency'),
    schema.from('providers').select('id,name,kind,enabled,monthly_limit,usage_count').order('name'),
    schema.from('revenue_sources').select('id,name,kind,enabled,commission_rate,payout_provider,payout_status').order('name')
  ]);
  const events = revenue.data ?? [];
  const total = events.filter(x => x.status === 'paid' || x.status === 'confirmed').reduce((s, x) => s + Number(x.amount ?? 0), 0);
  const pending = events.filter(x => x.status === 'pending').reduce((s, x) => s + Number(x.amount ?? 0), 0);
  return NextResponse.json({ configured: true, stats: { searches: searches.count ?? 0, clicks: clicks.count ?? 0, revenue: total, pending, currency: 'USD', providers: providers.data ?? [], sources: sources.data ?? [] } });
}
